<!DOCTYPE html>
<html lang="en">
    <?php
        include ("db.php");
    ?>
<!-- Mirrored from Karthik.netlify.com/index-creative1.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jan 2019 11:19:26 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="keywords" content="Personal, Portfolio, Creative">
        <meta name="description" content="Karthik Portfolio Template">
        <meta name="author" content="cosmos-themes">

        <title>Karthik - Portfolio Template</title>

        <!-- favicon -->
        <link href="images/favicon.ico" rel="icon" type="image/png">

        <!--Font Awesome css-->
        <link rel="stylesheet" href="css/font-awesome.min.css">

        <!--Bootstrap css-->
        <link rel="stylesheet" href="css/bootstrap.css">

        <!--Owl Carousel css-->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/owl.theme.default.min.css">

        <!--Magnific Popup css-->
        <link rel="stylesheet" href="css/magnific-popup.css">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:200,300,400,500,600,700,800,900%7cOpen+Sans:400,600,700,800" rel="stylesheet">

        <!--Site Main Style css-->
        <link rel="stylesheet" href="css/style.css">
        <style>
            section.services .service-item h4
            {
                color:#257218 !important;
            }
            
            .portfolio  img{
                width: 349px;
                height: 241px;
            }
            .blogs  img{
            width: 350px;
            height: 250px;
            }
    </style>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-122650090-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-122650090-1');
        </script>

    </head>

    <body>

        <!--Preloader-->
        <div class="preloader">
            <div class="loader "></div>
        </div>
        <!--Preloader-->

        <!--Navbar Start-->
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container">
                <!-- LOGO -->
                <a class="navbar-brand logo" href="index-2.html">
                    Karthik
                </a>
           
                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a href="#" class="nav-link active" data-scroll-nav="0" >Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" data-scroll-nav="1" >About</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" data-scroll-nav="2" >Services</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" data-scroll-nav="3">Works</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" data-scroll-nav="4">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" data-scroll-nav="5">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--Navbar End-->

        <!--Home Section Start-->
        <section id="home" class="banner" style="background-image: url('images/background/home-banner-bg.jpg')" data-stellar-background-ratio=".7" data-scroll-index="0">
            <div class="container">
                <!--Banner Content-->
                <div class="banner-caption">
                    <h1 >Hi! I'm <span style=""> Karthik.</span></h1>
                    <p class="cd-headline clip mt-30">
                        <span>Creative Designer & Developer located in Bangalore.</span><br>
                        <span class="blc">Specialized in</span>
                        <span class="cd-words-wrapper" >
                            <b class="is-visible">Creating Websites.</b>
                            <b>Creating Games.</b>
                            <b>Designing UI/UX.</b>
                            
                        </span>
                    </p>
                </div>
                <div class="arrow bounce">
                    <a class="fa fa-chevron-down fa-2x" href="#" data-scroll-nav="1"></a>
                </div>
            </div>
            <!--Creative Background Svg-->
            <svg id="home-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1400 300" preserveAspectRatio="none">
                <path class="p-curve" d="M0,96.1c109.9,67.5,145.1,201.1,329.6,202.5S1043.2,99.5,1400,0v300H0V96.1z"/>
            </svg>
        </section>
        <!--Home Section End-->

        <!--About Section Start-->
        <section class="about pt-100 pb-100" data-scroll-index="1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-6">
                        <!--About Image-->
                        <div class="about-img">
                            <img src="images/about-image.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-6">
                        <!--About Content-->
                        <div class="about-content">
                            <div class="about-heading">
                                <h2>About Me.</h2>
                                <span style="color:#257218 !important;"><b>UI/UX Designer</b> & <b>Web Developer</b> , <b>Game Developer</b></span>
                            </div>
                             <p>I'm <b>
                                        Karthik Subramanniyan</b>
                                        </br>
                                        This website provides u some sample web and game devlopment related industry standard products. And has been the industry's standard  ever since the 2017.
                            </p>
                            <p></p>
                            <!--About Social Icons-->
                            <div class="social-icons">
                                <a href="https://www.facebook.com/karthikbairav/?modal=admin_todo_tour"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </div>
                            <span class="about-button">
                                <a class="main-btn" href="#">Download CV</a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--About Section End-->

        <!--Services Section Start-->
        <section class="services bg-gray pt-100 pb-50" data-scroll-index="2">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="heading text-center">
                            <h6>Services</h6>
                            <h2>What I Can Do</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <!--Service Item-->
                        <div class="service-item">
                            <span class="icon">
                                <i class="fa fa-laptop"></i>
                            </span>
                            <h4>Web Design</h4>
                            <p>
                                The design of a website reflects the brand it is built for and we let you create it to the best by blending different technologies as per your business's unique requirements. 
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--Service Item-->
                        <div class="service-item">
                            <span class="icon">
                                <i class="fa fa-gears"></i>
                            </span>
                            <h4>Web Development</h4>
                            <p>
                                Versed in the different web technologies, our developers analyze your business requirements and deliver the best solutions while prioritizing your satisfaction.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--Service Item-->
                        <div class="service-item">
                            <span class="icon">
                                <i class="fa fa-mobile"></i>
                            </span>
                            <h4>Responsive Design</h4>
                            <p> We deliver real-time, customized and easy-to-use responsive designs that ensure the growth of your business through enhanced performance on the different devices.</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--Service Item-->
                        <div class="service-item">
                            <span class="icon">
                                <i class="fa fa-rocket"></i>
                            </span>
                            <h4>Game Design</h4>
                            <p>There will be some important lectures and samples given on game developement.</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--Service Item-->
                        <div class="service-item">
                            <span class="icon">
                                <i class="fa fa-pencil"></i>
                            </span>
                            <h4>SEO</h4>
                            <p>Lorem Ipsum is simply dummy text of the Lorem has been the industry's standard dummy text ever.</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--Service Item-->
                        <div class="service-item">
                            <span class="icon">
                                <i class="fa fa-support"></i>
                            </span>
                            <h4>Support</h4>
                            <p>Lorem Ipsum is simply dummy text of the Lorem has been the industry's standard dummy text ever.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Services Section End-->

        <!--Stats Section Start-->
        <section class="stats pt-100 pb-100" style="background-image: url('images/background/stats-bg.jpg')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <!--Stats Item-->
                        <div class="single-stat">
                            <span class="stat-icon">
                                <i class="fa fa-users" aria-hidden="true"></i>
                            </span>
                           
                            <p>Clients Satisfaction</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <!--Stats Item-->
                        <div class="single-stat">
                            <span class="stat-icon">
                                <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                            </span>
                          
                            <p>Projects Up to date</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <!--Stats Item-->
                        <div class="single-stat">
                            <span class="stat-icon">
                                <i class="fa fa-edit" aria-hidden="true"></i>
                            </span>
                           
                            <p>Standard Coding</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <!--Stats Item-->
                        <div class="single-stat">
                            <span class="stat-icon">
                                <i class="fa fa-trophy" aria-hidden="true"></i>
                            </span>
                          
                            <p>MORE</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Stats Section End-->


        <!--Portfolio Section Start-->
        <section class="portfolio pt-100 pb-70" data-scroll-index="3">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="heading text-center">
                            <h6>Portfolio</h6>
                            <h2>Work I Have Done</h2>
                        </div>
                        <div class="portfolio-filter text-center">
                            <ul>
                                <li class="sel-item" data-filter="*">All</li>
                                <li data-filter=".design">Web Design</li>
                                <li data-filter=".application">Applications</li>
                                <li data-filter=".development">Development</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row portfolio-items">
                    <!--Portfolio Item-->
                     <?php
                
                    $photo=array('img-1','img-2','img-3','img-4','img-5','img-6');
                    
                    $title=array('Application','Web Design','Game Design','Wordpress','Responsive design','Seo');
                    
                    
                    for($i=0;$i<sizeof($photo);$i++)
                    {
                        
                    echo '<div class="col-lg-4 col-md-6 item application development">
                        <div class="item-content">
                            <img src="images/portfolio/'.$photo[$i].'.jpg" alt="">
                            <div class="item-overlay">
                                <h6>'.$title[$i].'</h6>
                                <div class="icons">
                                    <span class="icon link">
                                        <a href="images/portfolio/'.$photo[$i].'.jpg">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>';
                    
                        
                        
                    }
                    
                    
                    
                    ?>
                </div>
            </div>
        </section>
        <!--Portfolio Section End-->

        <!--Blog Section Start-->
        <section class="blogs pt-100 pb-100 bg-gray" data-scroll-index="4">
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <div class="heading text-center">
                            <h6>Blog</h6>
                            <h2>Latest News</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="owl-carousel owl-theme">
                        <!--Blogs Item-->
                        <div class="blog-item">
                            <div class="blog-img">
                                <a href="single-blog.html">
                                    <img src="images/blog/img-1.jpg" alt="">
                                </a>
                            </div>
                            <div class="blog-content">
                                <h3>The best of web design and web design inspiration</h3>
                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first ...</p>
                                <div class="blog-meta">
                                    <span class="more">
                                        <a href="single-blog.html">Read More</a>
                                    </span>
                                    <span class="date">
                                        1/April/2018
                                    </span>
                                </div>
                            </div>
                        </div>
                        <!--Blogs Item-->
                        <div class="blog-item">
                            <div class="blog-img">
                                <a href="single-blog.html">
                                    <img src="images/blog/img-2.jpg" alt="">
                                </a>
                            </div>
                            <div class="blog-content">
                                <h3>The best of web design and web design inspiration</h3>
                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first ...</p>
                                <div class="blog-meta">
                                    <span class="more">
                                        <a href="single-blog.html">Read More</a>
                                    </span>
                                    <span class="date">
                                        1/April/2018
                                    </span>
                                </div>
                            </div>
                        </div>
                        <!--Blogs Item-->
                        <div class="blog-item">
                            <div class="blog-img">
                                <a href="single-blog.html">
                                    <img src="images/blog/img-3.jpg" alt="">
                                </a>
                            </div>
                            <div class="blog-content">
                                <h3>The best of web design and web design inspiration</h3>
                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first ...</p>
                                <div class="blog-meta">
                                    <span class="more">
                                        <a href="single-blog.html">Read More</a>
                                    </span>
                                    <span class="date">
                                        1/April/2018
                                    </span>
                                </div>
                            </div>
                        </div>
                        <!--Blogs Item-->
                        <div class="blog-item">
                            <div class="blog-img">
                                <a href="single-blog.html">
                                    <img src="images/blog/img-4.jpg" alt="">
                                </a>
                            </div>
                            <div class="blog-content">
                                <h3>The best of web design and web design inspiration</h3>
                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first ...</p>
                                <div class="blog-meta">
                                    <span class="more">
                                        <a href="single-blog.html">Read More</a>
                                    </span>
                                    <span class="date">
                                        1/April/2018
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col text-center">
                        <div class="blog-button pt-40">
                            <a class="main-btn" href="blogs-page.html">View More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Blog Section End-->

        <!--Testimonials Section Start-->
        <section class="testimonials pt-100 pb-100" style="background-image: url('images/background/testimonials-bg.jpg')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="owl-carousel owl-theme text-center">
                            <!--Testimonials Item-->
                            <div class="testimonial-item">
                                <div class="author-img">
                                    <img src="images/about-image.jpg" alt="">
                                </div>
                                <h5>Mr Karthik Subramanniyan</h5>
                                <span>Web & Game Developer</span>
                                <p>
                                    
                                </p>
                            </div>
                            <!--Testimonials Item-->
                         
                         
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Testimonials Section End-->

        <!--Contact Section Start-->
        <?php
        $nameErr = $emailErr = $genderErr = $websiteErr = "";
                                   $name = $email = $gender = $comment = $website = "";
         
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
           
             if (empty($_POST["user_name"])) {
               $nameErr = "Name is required";
            }else {
               $name = test_input($_POST["user_name"]);
            }
            
            if (empty($_POST["email"])) {
               $emailErr = "Email is required";
            }else {
               $email = test_input($_POST["email"]);
               
               // check if e-mail address is well-formed
               if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                  $emailErr = "Invalid email format"; 
               }
            }
            
            if (empty($_POST["comment"])) {
               $comment = "";
            }else {
               $comment = test_input($_POST["comment"]);
            }
            
         }
         
         function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
                        
                        ?>
        
        
        
        
        <section class="contact pt-100 pb-100" data-scroll-index="5">
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <div class="heading">
                            <h6>Contact</h6>
                            <h2>Get In Touch</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <!--Contact Form-->
                        <form id='contact-frm1' method='POST' action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> >
                           <input type='hidden' name='form-name' value='contactForm' />
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <!--name-->
                                    <input type="text" class="form-control con-validate" name="user_name" id="contact-name" placeholder="Name" minlength=3 ><?php echo $nameErr; ?>
                                </div>
                                <div class="col-md-6 form-group">
                                    <!--email-->
                                    <input type="email" class="form-control con-validate" name="email" id="contact-email" placeholder="Email" ><?php echo $emailErr; ?>
                                </div>
                                <div class="col-md-12 form-group">
                                    <!--message box-->
                                    <textarea class="form-control con-validate" name="comment" id="contact-message" placeholder="How can we help you?" rows=6 ></textarea>
                                </div>
                                <div class="col-md-12 text-center">
                                    <!--contact button-->
                                    <input type = "submit" name = "submit" value = "Submit"/>
                                </div>
                            </div>
                        </form>
                        
                                   
                        
                        
         <?php
                        
                        
 $sql = "INSERT INTO name (name, email, comment) VALUES ('$name', '$email', '$comment')";

if ($conn->query($sql) === TRUE) {
   // echo "New record created successfully";
} else {
    //echo "Error: " . $sql . "<br>" . $conn->error;
}

         
      ?>               
                        
                        
                        
                    </div>
                </div>
            </div>
        </section>
        <!--Contact Section End-->

        <!--Footer Start-->
        <footer class="pt-50 pb-50">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-3 col-sm-6">
                        <!--Contant Item-->
                        <div class="contact-info">
                            <h5>Karthik</h5>
                            <p>Web And Game Developer</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <!--Contant Item-->
                        <div class="contact-info">
                            <h5>Phone No.</h5>
                            <p>7892501949</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <!--Contant Item-->
                        <div class="contact-info">
                            <h5>Email</h5>
                            <p>karthibairav@gmail.com</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <!--Contant Item-->
                        <div class="contact-info">
                            <h5>Address</h5>
                            <p>Avalahalli Main Road
                            Girinagar 
                        Near Satallite,
                        Bangalore - 560085</p>
                        </div>
                    </div>
                </div>
                <div class="row text-center">
                    <div class="col-md-12">
                        <hr>
                        <p class="copy pt-30">
                            Karthik &copy; 2018. All Right Reserved, Designed By Cosmos-Themes.
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!--Footer End-->
<?php

if(isset($_POST['contact-submit']))
    
{
   
formvalidation();
}


?>
       
       
        <!--Jquery js-->
        <script src="js/jquery-3.3.1.min.js"></script>
        <!--Bootstrap js-->
        <script src="js/bootstrap.min.js"></script>
        <!--Stellar js-->
        <script src="js/jquery.stellar.js"></script>
        <!--Animated Headline js-->
        <script src="js/animated.headline.js"></script>
        <!--Owl Carousel js-->
        <script src="js/owl.carousel.min.js"></script>
        <!--ScrollIt js-->
        <script src="js/scrollIt.min.js"></script>
        <!--Isotope js-->
        <script src="js/isotope.pkgd.min.js"></script>
        <!--Magnific Popup js-->
        <script src="js/jquery.magnific-popup.min.js"></script>
        <!--Site Main js-->
        <script src="js/main.js"></script> 

    </body>

<!-- Mirrored from Karthik.netlify.com/index-creative1.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jan 2019 11:19:26 GMT -->
</html>

